<?php
namespace Addon\wapi\Controller;

use Common\Controller\CommonController;

class BaseController extends CommonController
{
	public function _initialize()
	{
		
	}

}