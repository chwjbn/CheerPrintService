<?php
return array(
   'APP_NAME'=>'CheerPrintService'
);